package project2;

public class Response 
{
    private int id;
    private String gender;
    private int age;
    private int Residence;
    private int Education;
    private int IncomeSource;
    private int MaritalStatus;
    private int Smoker;
    private int Year;
    private String Q9;
    private int Q10;
    private int Q11;
    private int Q12;
    private int Q13;
    private int Q14;
    private int Q15;
    private String Q16;
    private int Q17;
    private int Q18;
    private int Q19;
    private int Q20;
    private int Q21;
    private int Q22;
    private String Q23;
    private int Q24;
    private int Q25;
    private int Q26;
    private int Q27;
    private int Q28;
    private int Q29;
    private int Q30;
    private int Quality;

    //setters
    public void setId(int id) {
        this.id = id;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setResidence(int residence) {
        Residence = residence;
    }

    public void setEducation(int education) {
        Education = education;
    }

    public void setIncomeSource(int incomeSource) {
        IncomeSource = incomeSource;
    }

    public void setMaritalStatus(int maritalStatus) {
        MaritalStatus = maritalStatus;
    }

    public void setSmoker(int smoker) {
        Smoker = smoker;
    }

    public void setYear(int year) {
        Year = year;
    }

    public void setQ9(String q9) {
        Q9 = q9;
    }

    public void setQ10(int q10) {
        Q10 = q10;
    }

    public void setQ11(int q11) {
        Q11 = q11;
    }

    public void setQ12(int q12) {
        Q12 = q12;
    }

    public void setQ13(int q13) {
        Q13 = q13;
    }

    public void setQ14(int q14) {
        Q14 = q14;
    }

    public void setQ15(int q15) {
        Q15 = q15;
    }

    public void setQ16(String q16) {
        Q16 = q16;
    }

    public void setQ17(int q17) {
        Q17 = q17;
    }

    public void setQ18(int q18) {
        Q18 = q18;
    }

    public void setQ19(int q19) {
        Q19 = q19;
    }

    public void setQ20(int q20) {
        Q20 = q20;
    }

    public void setQ21(int q21) {
        Q21 = q21;
    }

    public void setQ22(int q22) {
        Q22 = q22;
    }

    public void setQ23(String q23) {
        Q23 = q23;
    }

    public void setQ24(int q24) {
        Q24 = q24;
    }

    public void setQ25(int q25) {
        Q25 = q25;
    }

    public void setQ26(int q26) {
        Q26 = q26;
    }

    public void setQ27(int q27) {
        Q27 = q27;
    }

    public void setQ28(int q28) {
        Q28 = q28;
    }

    public void setQ29(int q29) {
        Q29 = q29;
    }

    public void setQ30(int q30) {
        Q30 = q30;
    }

    public void setQuality(int quality) {
        Quality = quality;
    }

    //getters
    public int getId() {
        return id;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public int getResidence() {
        return Residence;
    }

    public int getEducation() {
        return Education;
    }

    public int getIncomeSource() {
        return IncomeSource;
    }

    public int getMaritalStatus() {
        return MaritalStatus;
    }

    public int getSmoker() {
        return Smoker;
    }

    public int getYear() {
        return Year;
    }

    public String getQ9() {
        return Q9;
    }

    public int getQ10() {
        return Q10;
    }

    public int getQ11() {
        return Q11;
    }

    public int getQ12() {
        return Q12;
    }

    public int getQ13() {
        return Q13;
    }

    public int getQ14() {
        return Q14;
    }

    public int getQ15() {
        return Q15;
    }

    public String getQ16() {
        return Q16;
    }

    public int getQ17() {
        return Q17;
    }

    public int getQ18() {
        return Q18;
    }

    public int getQ19() {
        return Q19;
    }

    public int getQ20() {
        return Q20;
    }

    public int getQ21() {
        return Q21;
    }

    public int getQ22() {
        return Q22;
    }

    public String getQ23() {
        return Q23;
    }

    public int getQ24() {
        return Q24;
    }

    public int getQ25() {
        return Q25;
    }

    public int getQ26() {
        return Q26;
    }

    public int getQ27() {
        return Q27;
    }

    public int getQ28() {
        return Q28;
    }

    public int getQ29() {
        return Q29;
    }

    public int getQ30() {
        return Q30;
    }

    public int getQuality() {
        return Quality;
    }

    //constructor
    public Response(int id, String gender, int age, int Residence, int Education, int IncomeSource, int MaritalStatus, int Smoker, int Year, String Q9, int Q10, int Q11, int Q12, int Q13, int Q14, int Q15, String Q16, int Q17, int Q18, int Q19, int Q20, int Q21, int Q22, String Q23, int Q24, int Q25, int Q26, int Q27, int Q28, int Q29, int Q30)
    {
        this.id = id;
        this.gender = gender;
        this.age = age;
        this.Residence = Residence;
        this.Education = Education;
        this.IncomeSource = IncomeSource;
        this.MaritalStatus = MaritalStatus;
        this.Smoker = Smoker;
        this.Year = Year;
        this.Q9 = Q9;
        this.Q10 = Q10;
        this.Q11 = Q11;
        this.Q12 = Q12;
        this.Q13 = Q13;
        this.Q14 = Q14;
        this.Q15 = Q15;
        this.Q16 = Q16;
        this.Q17 = Q17;
        this.Q18 = Q18;
        this.Q19 = Q19;
        this.Q20 = Q20;
        this.Q21 = Q21;
        this.Q22 = Q22;
        this.Q23 = Q23;
        this.Q24 = Q24;
        this.Q25 = Q25;
        this.Q26 = Q26;
        this.Q27 = Q27;
        this.Q28 = Q28;
        this.Q29 = Q29;
        this.Q30 = Q30;
        this.Quality = Q13 + Q14 + Q15 + Q17 + Q18 + Q19 + Q21 + Q22 + Q24 + Q25 + Q26 + Q27 + Q28 + Q29 + Q30;
    }

    public Response()
    {

    }

    public void printResponse()
    {
        System.out.println("ID: " + id);
        System.out.println("Gender: " + gender);
        System.out.println("Age: " + age);
        System.out.println("Residence: " + Residence);
        System.out.println("Education: " + Education);
        System.out.println("Income Source: " + IncomeSource);
        System.out.println("Marital Status: " + MaritalStatus);
        System.out.println("Smoker: " + Smoker);
    }

}
