# CSC172 Data Structures and Algorithms - Project 2
Krish Patel

In the assignment sheet, it was stated that each of the methods in the SurveyAnalyser class should take a parameter of a CustomHashTable object. My code does not implement this functionality since the provided Testing class does not work with this parameter. There is no need for this functionality since when creating an instance of the SurveyAnalyser class you must pass in the ReadFile object. From this, the SurveyAnalyser instance can access the CustomHashTable object.
